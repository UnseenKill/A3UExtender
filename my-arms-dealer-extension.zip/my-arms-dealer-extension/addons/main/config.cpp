#include "script_component.hpp"

class CfgPatches {
    class ADDON {
        name = CSTRING(component);
        units[] = {};
        weapons[] = {};
        requiredVersion = REQUIRED_VERSION;
        requiredAddons[] = {
            // Add dependency to Antistasi Ultimate
            "A3A_ultimate",
            // We're going to be adding stuff from RF
            "RF_Weapons"
        };
        // Make this mod load _only_ if all the above dependencies are satisfied
        skipWhenMissingDependencies = 1;
        author = CSTRING(Author);
        authors[] = {};
        url = CSTRING(URL);
        VERSION_CONFIG;
    };
};
