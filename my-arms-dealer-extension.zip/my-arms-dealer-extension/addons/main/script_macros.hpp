// The mod's main prefix as defined as "main prefix" during initialization
#define MAINPREFIX z
// Community Based Addons - common macros
#include "\x\cba\addons\main\script_macros_common.hpp"

// All your global mod-specific macros go after this line
/* ... */
#ifndef QPREFIX
    #define QPREFIX QUOTE(PREFIX)
#endif // QPREFIX
