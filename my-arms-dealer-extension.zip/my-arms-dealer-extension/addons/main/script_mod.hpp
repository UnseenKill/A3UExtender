// COMPONENT should be defined in the script_component.hpp and included BEFORE this hpp
#define PREFIX a3uemade

#include "script_version.hpp"

#define VERSION     MAJOR.MINOR
#define VERSION_STR MAJOR.MINOR.PATCHLVL.BUILD
#define VERSION_AR  MAJOR,MINOR,PATCHLVL,BUILD

// MINIMAL required Arma version for the Mod. Components can specify others..
#define REQUIRED_VERSION 2.20
