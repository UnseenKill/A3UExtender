#define COMPONENT store
#include "\z\a3uemade\addons\main\script_mod.hpp"
#include "\z\a3uemade\addons\main\script_macros.hpp"

// Macros _local_ to the addon (i.e. not used outside of it) go here
#define ITEM(CLASSNAME, PRICE, STOCK)\
    class CLASSNAME {\
        price = PRICE;\
        stock = STOCK;\
    }

#define MAGAZINE_STOCK 200
#define LAUNCHER_STOCK 15
#define PISTOL_STOCK 50
#define RIFLE_STOCK 20
#define MZ_STOCK 50
#define NN_STOCK 50
#define PN_STOCK 25
#define MISC_STOCK 50
