// Antistasi Ultimate configuration
class A3U {
    class traderAddons {
        class addons_base;

        // Our store class
        class DOUBLES(addons,PREFIX): addons_base {
            addons[] = {
                // Add a requirement to our mod, not just RF
                QUOTE(MAIN_ADDON),
                // We require RF_Weapons addon loaded; don't show store if not loaded.
                "RF_Weapons"
            };
            // Reference to traderWeapons sub-class below
            weapons = QUOTE(DOUBLES(weapons,PREFIX));
        };

        class traderWeapons {
            class weapons_base;
            class DOUBLES(weapons,PREFIX): weapons_base {
                // Defines the available store referenced below
                prefix = QUOTE(DOUBLES(PREFIX,store));
            };
        };
    };
};

// HALs store addon configuration
class CfgHALsAddons {
    class CfgHALsStore {
        class stores {
            class DOUBLES(PREFIX,store) {
                displayName = "$STR_ARMS_DEALER_STORE";
                categories[] = {
                    // Miscellaneous category defined below
                    QUOTE(TRIPLES(PREFIX,store,misc)),
                    // Weapons category defined below
                    QUOTE(TRIPLES(PREFIX,store,weapons))
                };
            };
        };

        class categories {
            class TRIPLES(PREFIX,store,misc) {
                // Result: "A3UEMADE - Miscellaneous"
                displayName = __EVAL(formatText ["%1 %2", QPREFIX, localize "STR_A3AU_misc"]);
                // Arma 3 backpack icon
                picture = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\backpack_ca.paa";

                /*
                    Add store items here.

                    We're using the ITEM() macro defined earlier in `script_component.hpp`

                    Syntax is:
                        ITEM(className,price,stock);
                */

                // Drone40 HE - base price: 5000, stock: three units
                ITEM(1Rnd_RC40_HE_shell_RF,5000,3);
                // Drone40 Blue Smoke - base price: 2500, stock: ten units
                ITEM(1Rnd_RC40_SmokeBlue_shell_RF,2500,10);
            };

            class TRIPLES(PREFIX,store,weapons) {
                // Result: "A3UEMADE - Rifles"
                displayName = __EVAL(formatText ["%1 %2", QPREFIX, localize "STR_A3AU_rifles"]);
                // Arma 3 long rifle icon
                picture = "a3\ui_f\data\gui\Rsc\RscDisplayArsenal\primaryWeapon_ca.paa";

                // Veles-S 12.7mm - base price: 3500, stock: A3U rifle default stock quantity (20 units)
                ITEM(arifle_ash12_LR_blk_RF,3500,RIFLE_STOCK);
            };
        };
    };
};
