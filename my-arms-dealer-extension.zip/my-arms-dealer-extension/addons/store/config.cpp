#include "script_component.hpp"

class CfgPatches {
    class ADDON {
        name = CSTRING(component);
        units[] = {};
        weapons[] = {};
        requiredVersion = REQUIRED_VERSION;
        requiredAddons[] = {
            // Require our main addon
            QUOTE(MAIN_ADDON),
            // We're updating A3U's store, so the HALS store addon is required, too
            "A3A_hals"
        };
        author = ECSTRING(main,Author);
        authors[] = {};
        url = ECSTRING(main,URL);
        VERSION_CONFIG;
    };
};

#include "CfgHalsStore.hpp"
